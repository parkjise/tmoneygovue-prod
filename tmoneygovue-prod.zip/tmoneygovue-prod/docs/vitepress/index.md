---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "티머니GO SPA 가이드"
  tagline: 주요 가이드
  actions:
    
    - theme: brand
      text: APP브릿지
      link: /bridge/web-to-native/auth-web-to-native
    - theme: alt
      text: Composable function
      link: /bridge/native-to-web/etc-native-to-web

# features:
#   - title: Feature A
#     details: Lorem ipsum dolor sit amet, consectetur adipiscing elit
#   - title: Feature B
#     details: Lorem ipsum dolor sit amet, consectetur adipiscing elit
#   - title: Feature C
#     details: Lorem ipsum dolor sit amet, consectetur adipiscing elit
---

