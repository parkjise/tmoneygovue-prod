---
outline: deep
---

# 공통처리

## 1. 로그아웃시 SPA WEBVIEW처리
- 로그아웃되면 기존 SPA WEBVIEW를 새로 생성 필요.(브라우저 메모리에 저장된 정보(store)를 초기화 시키키 위함)

## 2. TODO
