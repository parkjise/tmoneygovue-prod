<template>
  <sub-header title="사업자 정보" />
  <main id="main" class="main mor">
    <div class="container no_padding bg_white">
      <div class="setting legal">
        <div class="info">
          <h4>사업자 정보</h4>
          <ul>
            <li>주식회사 티머니 대표이사 : 김태극</li>
            <li>통신판매업 신고번호 : 2013-서울중구-0272</li>
            <li>사업자 등록번호 : 104-81-83559</li>
            <li>전화번호 : 1644-0088</li>
            <li>사업장 소재지 : 서울시 중구 후암로 110</li>
            <li>Copyright ⓒ Tmoney. All rights reserved.</li>
            <li>
              <br />(주)티머니는 티머니GO에 있어, 통신판매중개자이며 통신판매의 당사자가 아니므로 개별 사업자가 표시하는
              거래정보 및 거래 등에 대하여 책임을 지지 않습니다.
            </li>
          </ul>
        </div>
      </div>
    </div>
  </main>
</template>
