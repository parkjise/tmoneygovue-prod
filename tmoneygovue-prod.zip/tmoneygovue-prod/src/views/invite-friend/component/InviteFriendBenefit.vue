<template>
  <div class="benefit_warp">
    <div class="deco_top"><img src="/assets/images/invite_promotion/icon_benefit_deco_top_card.svg" /></div>
    <div class="deco_bottom">
      <div class="title">
        <h5 class="tmoney">친구초대에 참여하면 받아갈 수 있는</h5>
        <h3>
          <svg view-box="0 0 150 35" role="img" aria-labelledby="benefitsTitle">
            <title id="benefitsTitle">혜택 모아보기</title>
            <text class="title_bottom" x="75" y="26">혜택 모아보기</text>
            <text class="title_mid" x="75" y="23">혜택 모아보기</text>
            <text class="title_top" x="75" y="23">혜택 모아보기</text>
          </svg>
        </h3>
      </div>
      <ul class="benefit_list">
        <li class="benefit">
          <p class="tmoney">01</p>
          <ul class="benefit_disc">
            <li class="left_icon">
              <img src="/assets/images/invite_promotion/icon_benefit_01.svg" />
            </li>
            <li class="right_text">
              <h3>
                친구 초대 1회당
                <span class="big_text">
                  <svg role="img" aria-labelledby="benefitsPoint">
                    <title id="benefitsPoint">500M</title>
                    <text class="text_bottom" x="50%" y="30" dominant-baseline="middle">500M</text>
                    <text class="text_mid" x="50%" y="20" dominant-baseline="middle">500M</text>
                    <text class="text_top" x="50%" y="20" dominant-baseline="middle">500M</text>
                  </svg>
                </span>
                씩 지급!
              </h3>
              <p class="note">* 친구가 초대코드 입력 후 회원가입 시</p>
            </li>
          </ul>
        </li>
        <li class="benefit middle">
          <p class="tmoney">02</p>
          <ul class="benefit_disc">
            <li class="left_icon">
              <img src="/assets/images/invite_promotion/icon_benefit_02.svg" />
            </li>
            <li class="right_text">
              <h3>
                초대받은 친구는
                <span class="big_text">
                  <svg class="view_box" role="img" aria-labelledby="benefitsAmount">
                    <title id="benefitsAmount">2,000원</title>
                    <text class="text_bottom" x="50%" y="30" dominant-baseline="middle">2,000원</text>
                    <text class="text_mid" x="50%" y="20" dominant-baseline="middle">2,000원</text>
                    <text class="text_top" x="50%" y="20" dominant-baseline="middle">2,000원</text>
                  </svg>
                </span>
                쿠폰 획득!
              </h3>
              <p class="note">* 티머니GO 모든 서비스 사용 가능!</p>
            </li>
          </ul>
        </li>
        <li class="benefit">
          <p class="tmoney">BONUS!</p>
          <ul class="benefit_disc">
            <li class="left_icon">
              <img src="/assets/images/invite_promotion/icon_benefit_bonus.svg" />
            </li>
            <li class="right_text">
              <p class="description">초대받은 친구가 2,000원 쿠폰 사용하면</p>
              <h3>
                초대한 친구에게
                <span class="big_text">
                  <svg view-box="0 0 60 30" role="img" aria-labelledby="benefitsBonusPoint">
                    <title id="benefitsBonusPoint">500마일리지</title>
                    <text class="text_bottom" x="50%" y="30" dominant-baseline="middle">500M</text>
                    <text class="text_mid" x="50%" y="20" dominant-baseline="middle">500M</text>
                    <text class="text_top" x="50%" y="20" dominant-baseline="middle">500M</text>
                  </svg>
                </span>
                한번 더!
              </h3>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</template>
