<template>
  <div class="inv_guide_wrap">
    <div class="inv_guide">
      <div class="title">
        <h5>우정과 혜택 획득을 위한</h5>
        <h3>
          <svg role="img" aria-labelledby="svgTitle">
            <title id="svgTitle">친구 초대 방법</title>
            <text x="75" y="26" class="text_bottom">친구 초대 방법</text>
            <text x="75" y="23" class="text_mid">친구 초대 방법</text>
            <text x="75" y="23">친구 초대 방법</text>
          </svg>
        </h3>
      </div>
      <ul class="invitation_step_list">
        <li>
          <span class="tmoney step">STEP 01</span>
          <h4>친구에게 나의 초대코드를 공유해요</h4>
        </li>
        <li>
          <span class="tmoney step">STEP 02</span>
          <h4>초대받은 친구는 티머니GO에 가입해주세요</h4>
          <div class="add_info">
            <p>
              <img src="/assets/images/ic/ic_16_alert_white.svg" alt="유의사항 아이콘" aria-label="유의사항 아이콘" />
              회원가입 시 <span>초대한 친구의 초대코드</span>를<br />
              꼭 입력해 주세요!
            </p>
          </div>
        </li>
        <li>
          <span class="tmoney step">STEP 03</span>
          <h4>가입완료 확인되면<br />나와 친구에게 모두 혜택 지급!</h4>
        </li>
      </ul>
    </div>
  </div>
</template>
