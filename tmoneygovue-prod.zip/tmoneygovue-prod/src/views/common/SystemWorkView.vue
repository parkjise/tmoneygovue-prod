<template>
  <main class="main system_work" />
</template>
