<template>
  <router-view />
  <!-- <sample-Bottom-navi-layout v-if="isLocal()" /> -->
</template>

<script setup lang="ts">
// import SampleBottomNaviLayout from './sample/SampleBottomNaviLayout.vue';
// import { isLocal } from '@/utils/is';
</script>

<style scoped></style>
