/**
 * @description: person1Model
 */
export interface person1Model {
  name: string;
  age: number;
  computedNameLength: number;
}
