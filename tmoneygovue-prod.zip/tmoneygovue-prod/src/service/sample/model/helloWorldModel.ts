/**
 * @description: HellowModel
 */
export interface HellowModel {
  helloText: string;
}
