export type ImgDataRequest = {
  imgData: string;
};
