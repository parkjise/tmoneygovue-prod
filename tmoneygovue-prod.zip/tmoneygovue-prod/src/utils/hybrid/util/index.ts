// // nativeToWeb interFace 정의
export type CallBackFunction = () => void;
export { UtilNativeToWeb } from './nativeToWeb';
