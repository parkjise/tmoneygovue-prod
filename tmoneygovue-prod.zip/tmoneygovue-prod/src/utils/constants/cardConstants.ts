/**
 * 간편결제 카드 코드에 따른 calss 제공
 */
export const CardClass: { [key: number]: string } = {
  41: 'woori',
  45: 'mg',
  48: 'sinhyup',
  71: 'post',
  361: 'bc',
  364: 'gwangju',
  365: 'samsung',
  367: 'hyundai',
  368: 'lotte',
  369: 'suhyup',
  370: 'citi',
  371: 'nh',
  372: 'jeonbook',
  374: 'hana',
  381: 'kb',
  366: 'shinhan',
  999: 'tmoney'
};
