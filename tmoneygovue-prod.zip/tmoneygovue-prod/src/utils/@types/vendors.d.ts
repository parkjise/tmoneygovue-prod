declare module 'swiper-vue';
declare module 'prismjs';
