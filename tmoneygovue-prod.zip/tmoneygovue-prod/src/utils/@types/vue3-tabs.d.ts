declare module 'vue3-tabs';
